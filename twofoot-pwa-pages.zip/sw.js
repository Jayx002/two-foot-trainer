self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open('twofoot-cache-v1').then((cache) => cache.addAll([
      './',
      './index.html',
      './manifest.webmanifest',
      './sw.js',
      './assets/logo.jpg',
      './assets/icons/icon-192.png',
      './assets/icons/icon-256.png',
      './assets/icons/icon-512.png',
      './assets/icons/icon-512-maskable.png'
    ]))
  );
});
self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((resp) => resp || fetch(e.request))
  );
});